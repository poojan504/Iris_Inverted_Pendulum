#!/usr/bin/env python


""" Configure a cart-pole system spawned in Gazebo to be a qualified environment for reinforcement learning """


from __future__ import print_function

import numpy as np
import math
import random
import time

import rospy
from std_msgs.msg import (UInt16, Float64)
from sensor_msgs.msg import JointState



# Simulation geometry
MASS_POLE = 2
LENGTH_POLE = 0.5
RADIUS = 0.01
RADIUS_POLE = 0.025